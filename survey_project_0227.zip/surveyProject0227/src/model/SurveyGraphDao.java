package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class SurveyGraphDao {

	public SurveyGraphDto getResults(String gender, String age) {
		SurveyGraphDto dto = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = "SELECT HEALTH, ECO, SOCIAL FROM SATI_RESULT WHERE GENDER=? AND AGE=?";
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, gender);
			pstmt.setString(2, age);
			rs = pstmt.executeQuery();
			System.out.println("빅데이터 " + gender + " : " + age);
			while(rs.next()) {
				dto = new SurveyGraphDto();
				dto.setHealth(rs.getInt("HEALTH"));
				dto.setEco(rs.getInt("ECO"));
				dto.setSocial(rs.getInt("SOCIAL"));
			}
			 
		}	catch (Exception e){
			e.printStackTrace();
		}
		return dto;
	}
	
	private Connection getConnection() {
		Context context = null;
		DataSource dataSource = null;
		Connection conn = null;
		
		try {
			context = new InitialContext();
			dataSource = (DataSource)context.lookup("java:comp/env/jdbc/Oracle11g");
			conn = dataSource.getConnection();
		}
		catch (Exception e){
			e.printStackTrace();
		}
		
		return conn;
		
	} 
}
