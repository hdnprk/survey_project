package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import command.SurveyCommand;
import command.SurveyGraphCommand;
import command.SurveyScoreCommand;

@WebServlet("*.do")
public class Survey_Controller extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doGet");
		actionDo(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("doPost");
		actionDo(request, response);
	}

	private void actionDo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("actionDo");
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html:charset=UTF-8");
		
		SurveyCommand command = null;
		String uri = request.getRequestURI();
		String conPath = request.getContextPath();
		String com = uri.substring(conPath.length());
		
		if(com.equals("/surveyInsertScore.do")) {
			command = new SurveyScoreCommand();
			command.execute(request, response);
		} else if(com.equals("/surveyGraph.do")) {	// 평균값 조회하기
			command = new SurveyGraphCommand();
			command.execute(request, response);
		} 
//		RequestDispatcher rd = request.getRequestDispatcher("survey.jsp");
//		rd.forward(request, response);
	}

}
