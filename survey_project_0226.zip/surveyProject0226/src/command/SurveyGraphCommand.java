package command;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import model.SurveyDao;
import model.SurveyDto;
import model.SurveyGraphDao;
import model.SurveyGraphDto;

public class SurveyGraphCommand implements SurveyCommand {
	
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		
		SurveyGraphDao dao = new SurveyGraphDao();
		
		// 연령 구분값을 파라미터로 받아 평균값 조회 (빅데이터용)
		SurveyGraphDto dto = dao.getResults(request.getParameter("gender"), request.getParameter("age"));
		if(dto != null) {
			
			JSONObject jObj = new JSONObject();
			jObj.put("avgHth", dto.getHealth());
			jObj.put("avgEco", dto.getEco());
			jObj.put("avgRel", dto.getSocial());
			
			try {
				response.setContentType("application/x-json; charset=utf-8");
				response.getWriter().print(jObj.toString());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		// 테스트
		request.setAttribute("totHth", request.getParameter("score1"));
		request.setAttribute("totEco", request.getParameter("score2"));
		request.setAttribute("totRel", request.getParameter("score3"));
		
		request.setAttribute("totHth2", request.getParameter("avgHth"));
		request.setAttribute("totEco2", request.getParameter("avgEco"));
		request.setAttribute("totRel2", request.getParameter("avgRel"));
	}
}
