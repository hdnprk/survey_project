        // 제출 버튼 -> 평균 그래프 보기 버튼 -> 정책 보기 버튼 이동
        // 100은 top위치에서 100만큼 위로 조정, 50은 0.05초
//        function fnMove(move) {
//        	var offset = $("#section2" + move).offset();
//            $('html, body').animate({ scrollTop: offset.top - 100 }, 50);
//        }
//
//        function fnMove2(move2) {
//            var offset = $("#section3" + move2).offset();
//            $('html, body').animate({ scrollTop: offset.top - 100 }, 50);
//        }
//        
//        function fnMove3(move3) {
//            var offset = $("#section4" + move3).offset();
//            $('html, body').animate({ scrollTop: offset.top - 100 }, 50);
//        }
        
        
        
        $(function(){
            $('#policySubmit').on("click",function () {
            	// 화면 새로고침 방지
            	event.preventDefault();
            	
                var surveyform = $("#surveyform").serialize();
                $.ajax({
                    url: "./surveyInsertScore.do",
                    type: "post",
                    async: false,	// 동기 통신
                    data: surveyform,
                    dataType: 'json',
                    success: function (response) {
                		document.getElementById('score0').innerText = response.totScore;
                		document.getElementById('score1').innerText = response.totHth;
                		document.getElementById('score2').innerText = response.totEco;
                		document.getElementById('score3').innerText = response.totRel;
                		
                    	// 통신 성공이면 스크롤 이동하믐 펑션 호출
                    	fnMove2();
                    },
                    error: function (request, status, error) {
                    }
                });
            });
            $('#graphSubmit').on("click",function () {
            	event.preventDefault();
            	
                var gen = $("input[name='com1']:checked").val();
                var age = $("input[name='com2']:checked").val();
                
                $.ajax({
                    url: "./surveyGraph.do",
                    type: "post",
                    async: false,
                    dataType : 'json',
                    data: {
                        "gen": gen, "age": age
                    },
                    success: function (response) {
                    	fnMove3();
                    	
                    	// 내 점수, 평균 점수
/*                    	var totHth = document.getElementById('score1').innerText;
                    	var totEco = document.getElementById('score2').innerText;
                    	var totRel = document.getElementById('score3').innerText;*/
                    	var totScore = document.getElementById('score0').innerText;
                    	var totScore2 = response.totoScore;
                    	fnMove4(totScore, totScore2);
                    },
                    error: function (request, status, error) {
                    }
                });
            });
        });

        function fnMove(move) {
        	var offset = $("#section2").offset();
            $('html, body').animate({ scrollTop: offset.top - 100 }, 50);
        }

        function fnMove2(move2) {
            var offset = $("#section3").offset();
            $('html, body').animate({ scrollTop: offset.top - 100 }, 50);
        }

        function fnMove3(move3) {
            var offset = $("#section4").offset();
            $('html, body').animate({ scrollTop: offset.top - 100 }, 50);
        }


        function fnMove4(totScore, totScore2) {

        	var data = {
                    labels: ['나의 삶의 만족도', '나와 같은 사람의 삶의 만족도' ],
                    datasets: [{
                    label: '삶의 만족도 비교',
                    data: [totScore, response.totScore],
                    backgroundColor: ['red', 'orange'],
                    }]
                };
                var ctx = document.getElementById('myChart').getContext('2d');
                var myChart = new Chart(ctx, {
                type: 'bar',
                data: data,
                options: {}
                });
        	
        	/*var data = {
                    labels: ['건강', '경제', '사회적 관계'],
                    datasets: [{
                    label: '나와 같은 연령대 삶의 만족도 평균',
                    data: [totHth2, totEco2, totRel2],
                    backgroundColor: ['red', 'orange', 'yellow'],
                    }]
                };
                var ctx = document.getElementById('yourChart').getContext('2d');
                var myChart = new Chart(ctx, {
                type: 'bar',
                data: data,
                options: {}
                });
                
                var charts = document.querySelectorAll('#myChart, #yourChart');*/
                
                charts.forEach(function(chart) {
                	chart.style.maxWidth = '600px';
                	chart.style.height = '400px';
                	chart.style.margin = 'auto';
                	chart.style.border = '2px solid #ccc';
                	chart.style.boxShadow = '0 4px 8px rgba (0,0,0,0.1)';
                	chart.style.backgroundColor = '#f9f9f9';
                });
                
        }