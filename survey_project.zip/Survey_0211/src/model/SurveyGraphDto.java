package model;

public class SurveyGraphDto {
	
	private String totScore;

	public String getTotScore() {
		return totScore;
	}

	public void setTotScore(String totScore) {
		this.totScore = totScore;
	}

}
