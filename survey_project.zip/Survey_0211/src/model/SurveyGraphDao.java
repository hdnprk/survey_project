package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class SurveyGraphDao {

		public SurveyGraphDto getAvgSurvey(String gen, String age){
			SurveyGraphDto dto = null;
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String query = "SELECT totscore FROM sati_result WHERE gender = ? AND age = ?";
			
			try {
				conn = getConnection();
				pstmt = conn.prepareStatement(query);
				pstmt.setString(1, gen);
				pstmt.setString(2, age);
				rs = pstmt.executeQuery();
				
				System.out.println("서베이평균 : "+gen+" : "+age);
				while (rs.next()) {
					dto = new SurveyGraphDto();
					dto.setTotScore(rs.getString("totScore"));
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			return dto;
		}
		
		private Connection getConnection() {
			Context context = null;
			DataSource dataSource = null;
			Connection conn = null;
			
			try {
				context = new InitialContext();
				dataSource = (DataSource)context.lookup("java:comp/env/jdbc/Oracle11g");
				conn = dataSource.getConnection();
			}
			catch (Exception e){
				e.printStackTrace();
			}
			
			return conn;
		} 
}



