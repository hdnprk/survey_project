package command;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import model.SurveyDao;
import model.SurveyDto;
import model.SurveyGraphDao;
import model.SurveyGraphDto;

public class SurveyGraphCommand implements SurveyCommand {
	
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		
		SurveyGraphDao dao = new SurveyGraphDao();
		
		SurveyGraphDto avgDto = dao.getAvgSurvey(request.getParameter("gen"), request.getParameter("age"));
		if(avgDto != null) {
			
			JSONObject jObj = new JSONObject();
			jObj.put("totScore", avgDto.getTotScore());
			
			try {
				response.setContentType("application/x-json; charset=utf-8");
				response.getWriter().print(jObj.toString());
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
		
		request.setAttribute("totScore", request.getParameter("score0"));
	}
}



